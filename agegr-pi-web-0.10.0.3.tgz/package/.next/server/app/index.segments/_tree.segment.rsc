:HL["/_next/static/media/7deddc85b7ffd1dc-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/ec14413c594b3356-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/88714c00e109ce28.css","style"]
:HL["/_next/static/css/68dcfd9f73879adb.css","style"]
:HL["/_next/static/css/2da826216fd8066e.css","style"]
:HL["/_next/static/css/691bc590f1132a1e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"IDVl_N2jXV0fREm1jvnu9"}
