:HL["/_next/static/media/7deddc85b7ffd1dc-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/ec14413c594b3356-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/9bcd6051db4f8890.css","style"]
:HL["/_next/static/css/a53f173263a4ba3d.css","style"]
:HL["/_next/static/css/f2438a05b1032c80.css","style"]
:HL["/_next/static/css/691bc590f1132a1e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"uXGelMZ2Sq6YP0rCBDwj5"}
