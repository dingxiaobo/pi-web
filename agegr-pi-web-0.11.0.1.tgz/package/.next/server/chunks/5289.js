"use strict";exports.id=5289,exports.ids=[5289],exports.modules={55289:(a,b,c)=>{c.d(b,{diagram:()=>f});var d=c(6208);c(23464),c(30917),c(17822),c(89463),c(51467),c(79440),c(48514),c(50396),c(38847),c(45037),c(69579),c(39317),c(29179),c(12569),c(12644),c(58715);var e=(0,c(95097).K)(a=>`${(0,d.tM)(a)}
  .swimlane.cluster rect {
    stroke: ${a.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),f=(0,d.ur)({defaultLayout:"swimlane",styles:e})}};