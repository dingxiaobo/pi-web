:HL["/_next/static/media/7deddc85b7ffd1dc-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/ec14413c594b3356-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/88714c00e109ce28.css","style"]
:HL["/_next/static/css/c4dc2a96aa1b418d.css","style"]
:HL["/_next/static/css/b9be0269b72bbcb9.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"Ra6iJ-tP7kybZ8y1vpmJF"}
